clear
echo '                    
            __   __     _____   __       __       _____    
           /\_\ /_/\  /\_____\ /\_\     /\_\     ) ___ (   
          ( ( (_) ) )( (_____/( ( (    ( ( (    / /\_/\ \  
           \ \___/ /  \ \__\   \ \_\    \ \_\  / /_/ (_\ \ 
           / / _ \ \  / /__/_  / / /__  / / /__\ \ )_/ / / 
          ( (_( )_) )( (_____\( (_____(( (_____(\ \/_\/ /  
           \/_/ \_\/  \/_____/ \/_____/ \/_____/ )_____(   
                                                 
' | lolcat
echo " "
echo "                             About"|lolcat
echo " "
echo "       🙏 Hey, there I am Nakeeb (Nitro), i made this tool
       to create ngrok tunnel without hotspot, so i hope guys you
                             liked it. 😘"
echo ""
echo "                  Our channel :- Noob Hackers"| lolcat
echo " "
sleep 8.0
cd $HOME/tunnel
bash tunnel.sh

